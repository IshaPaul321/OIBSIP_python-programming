"use client"

import { useState, useCallback, useEffect } from "react"
import { Copy, RefreshCw, Check, Shield, ShieldAlert, ShieldCheck, Eye, EyeOff } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { toast } from "sonner"

const LOWERCASE = "abcdefghijklmnopqrstuvwxyz"
const UPPERCASE = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
const NUMBERS = "0123456789"
const SYMBOLS = "!@#$%^&*()_+-=[]{}|;:,.<>?"

interface PasswordOptions {
  length: number
  includeLowercase: boolean
  includeUppercase: boolean
  includeNumbers: boolean
  includeSymbols: boolean
  excludeChars: string
}

function calculateStrength(password: string, options: PasswordOptions): { score: number; label: string; color: string } {
  let score = 0
  
  // Length scoring
  if (password.length >= 8) score += 1
  if (password.length >= 12) score += 1
  if (password.length >= 16) score += 1
  if (password.length >= 20) score += 1
  
  // Character variety scoring
  const hasLower = /[a-z]/.test(password)
  const hasUpper = /[A-Z]/.test(password)
  const hasNumber = /[0-9]/.test(password)
  const hasSymbol = /[!@#$%^&*()_+\-=\[\]{}|;:,.<>?]/.test(password)
  
  const varietyCount = [hasLower, hasUpper, hasNumber, hasSymbol].filter(Boolean).length
  score += varietyCount
  
  // Calculate final score (0-8 -> 0-100)
  const normalizedScore = Math.min(100, (score / 8) * 100)
  
  if (normalizedScore < 30) return { score: normalizedScore, label: "Weak", color: "bg-destructive" }
  if (normalizedScore < 60) return { score: normalizedScore, label: "Fair", color: "bg-warning" }
  if (normalizedScore < 80) return { score: normalizedScore, label: "Good", color: "bg-chart-1" }
  return { score: normalizedScore, label: "Strong", color: "bg-success" }
}

export function PasswordGenerator() {
  const [password, setPassword] = useState("")
  const [showPassword, setShowPassword] = useState(true)
  const [copied, setCopied] = useState(false)
  const [options, setOptions] = useState<PasswordOptions>({
    length: 16,
    includeLowercase: true,
    includeUppercase: true,
    includeNumbers: true,
    includeSymbols: true,
    excludeChars: "",
  })

  const generatePassword = useCallback(() => {
    let charset = ""
    if (options.includeLowercase) charset += LOWERCASE
    if (options.includeUppercase) charset += UPPERCASE
    if (options.includeNumbers) charset += NUMBERS
    if (options.includeSymbols) charset += SYMBOLS

    // Remove excluded characters
    if (options.excludeChars) {
      const excludeSet = new Set(options.excludeChars.split(""))
      charset = charset.split("").filter(char => !excludeSet.has(char)).join("")
    }

    if (charset.length === 0) {
      toast.error("Please select at least one character type")
      return
    }

    // Use crypto API for better randomness
    const array = new Uint32Array(options.length)
    crypto.getRandomValues(array)
    
    let newPassword = ""
    for (let i = 0; i < options.length; i++) {
      newPassword += charset[array[i] % charset.length]
    }

    setPassword(newPassword)
    setCopied(false)
  }, [options])

  useEffect(() => {
    generatePassword()
  }, [generatePassword])

  const copyToClipboard = async () => {
    if (!password) return
    
    try {
      await navigator.clipboard.writeText(password)
      setCopied(true)
      toast.success("Password copied to clipboard!")
      setTimeout(() => setCopied(false), 2000)
    } catch {
      toast.error("Failed to copy password")
    }
  }

  const strength = calculateStrength(password, options)

  const StrengthIcon = strength.label === "Weak" ? ShieldAlert : 
                       strength.label === "Strong" ? ShieldCheck : Shield

  return (
    <Card className="w-full max-w-lg border-border/50 bg-card/80 backdrop-blur-sm">
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center gap-2 text-xl">
          <Shield className="h-5 w-5 text-primary" />
          Password Generator
        </CardTitle>
        <CardDescription>
          Generate secure, random passwords with custom options
        </CardDescription>
      </CardHeader>
      
      <CardContent className="space-y-6">
        {/* Password Display */}
        <div className="space-y-3">
          <div className="relative">
            <div className="flex items-center gap-2 rounded-lg border border-border bg-muted/50 p-4">
              <code className="flex-1 font-mono text-lg break-all text-foreground">
                {showPassword ? password : "•".repeat(password.length)}
              </code>
              <div className="flex items-center gap-1 shrink-0">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setShowPassword(!showPassword)}
                  className="h-8 w-8 text-muted-foreground hover:text-foreground"
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={copyToClipboard}
                  className="h-8 w-8 text-muted-foreground hover:text-foreground"
                >
                  {copied ? <Check className="h-4 w-4 text-success" /> : <Copy className="h-4 w-4" />}
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={generatePassword}
                  className="h-8 w-8 text-muted-foreground hover:text-foreground"
                >
                  <RefreshCw className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>

          {/* Strength Indicator */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-2">
                <StrengthIcon className={`h-4 w-4 ${
                  strength.label === "Weak" ? "text-destructive" :
                  strength.label === "Strong" ? "text-success" :
                  strength.label === "Good" ? "text-primary" : "text-warning"
                }`} />
                <span className="text-muted-foreground">Strength:</span>
                <span className={`font-medium ${
                  strength.label === "Weak" ? "text-destructive" :
                  strength.label === "Strong" ? "text-success" :
                  strength.label === "Good" ? "text-primary" : "text-warning"
                }`}>
                  {strength.label}
                </span>
              </div>
              <span className="text-muted-foreground font-mono text-xs">
                {password.length} characters
              </span>
            </div>
            <div className="h-2 w-full rounded-full bg-muted overflow-hidden">
              <div
                className={`h-full transition-all duration-300 ${strength.color}`}
                style={{ width: `${strength.score}%` }}
              />
            </div>
          </div>
        </div>

        {/* Length Control */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <Label htmlFor="length" className="text-sm font-medium">
              Password Length
            </Label>
            <Input
              type="number"
              min={4}
              max={64}
              value={options.length}
              onChange={(e) => {
                const val = parseInt(e.target.value, 10)
                if (!isNaN(val)) {
                  setOptions(prev => ({ ...prev, length: Math.min(64, Math.max(4, val)) }))
                }
              }}
              className="w-20 h-8 text-center font-mono text-sm bg-muted/30"
            />
          </div>
          <input
            type="range"
            id="length"
            min={4}
            max={64}
            step={1}
            value={options.length}
            onChange={(e) => setOptions(prev => ({ ...prev, length: parseInt(e.target.value, 10) }))}
            className="w-full h-2 bg-muted rounded-lg appearance-none cursor-pointer accent-primary"
          />
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>4</span>
            <span>64</span>
          </div>
        </div>

        {/* Character Type Options */}
        <div className="space-y-3">
          <Label className="text-sm font-medium">Character Types</Label>
          <div className="grid grid-cols-2 gap-3">
            <div className="flex items-center space-x-3 rounded-lg border border-border/50 bg-muted/30 p-3">
              <Checkbox
                id="lowercase"
                checked={options.includeLowercase}
                onCheckedChange={(checked) => 
                  setOptions(prev => ({ ...prev, includeLowercase: checked as boolean }))
                }
              />
              <Label htmlFor="lowercase" className="text-sm cursor-pointer flex-1">
                Lowercase
                <span className="block text-xs text-muted-foreground font-mono">a-z</span>
              </Label>
            </div>
            
            <div className="flex items-center space-x-3 rounded-lg border border-border/50 bg-muted/30 p-3">
              <Checkbox
                id="uppercase"
                checked={options.includeUppercase}
                onCheckedChange={(checked) => 
                  setOptions(prev => ({ ...prev, includeUppercase: checked as boolean }))
                }
              />
              <Label htmlFor="uppercase" className="text-sm cursor-pointer flex-1">
                Uppercase
                <span className="block text-xs text-muted-foreground font-mono">A-Z</span>
              </Label>
            </div>
            
            <div className="flex items-center space-x-3 rounded-lg border border-border/50 bg-muted/30 p-3">
              <Checkbox
                id="numbers"
                checked={options.includeNumbers}
                onCheckedChange={(checked) => 
                  setOptions(prev => ({ ...prev, includeNumbers: checked as boolean }))
                }
              />
              <Label htmlFor="numbers" className="text-sm cursor-pointer flex-1">
                Numbers
                <span className="block text-xs text-muted-foreground font-mono">0-9</span>
              </Label>
            </div>
            
            <div className="flex items-center space-x-3 rounded-lg border border-border/50 bg-muted/30 p-3">
              <Checkbox
                id="symbols"
                checked={options.includeSymbols}
                onCheckedChange={(checked) => 
                  setOptions(prev => ({ ...prev, includeSymbols: checked as boolean }))
                }
              />
              <Label htmlFor="symbols" className="text-sm cursor-pointer flex-1">
                Symbols
                <span className="block text-xs text-muted-foreground font-mono">{"!@#$%..."}</span>
              </Label>
            </div>
          </div>
        </div>

        {/* Exclude Characters */}
        <div className="space-y-2">
          <Label htmlFor="exclude" className="text-sm font-medium">
            Exclude Characters
          </Label>
          <Input
            id="exclude"
            placeholder="Characters to exclude (e.g., 0O1lI)"
            value={options.excludeChars}
            onChange={(e) => setOptions(prev => ({ ...prev, excludeChars: e.target.value }))}
            className="font-mono bg-muted/30"
          />
          <p className="text-xs text-muted-foreground">
            Enter any characters you want to exclude from the generated password
          </p>
        </div>

        {/* Generate Button */}
        <Button 
          onClick={generatePassword} 
          className="w-full font-semibold"
          size="lg"
        >
          <RefreshCw className="mr-2 h-4 w-4" />
          Generate New Password
        </Button>
      </CardContent>
    </Card>
  )
}
