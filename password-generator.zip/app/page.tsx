import { PasswordGenerator } from "@/components/password-generator"
import { Toaster } from "sonner"

export default function Home() {
  return (
    <main className="min-h-screen flex items-center justify-center p-4 md:p-8">
      <div className="w-full max-w-lg">
        <div className="text-center mb-8">
          <h1 className="text-3xl md:text-4xl font-bold tracking-tight text-foreground mb-2">
            Secure Password Generator
          </h1>
          <p className="text-muted-foreground text-balance">
            Create strong, unique passwords to keep your accounts safe
          </p>
        </div>
        <PasswordGenerator />
        <p className="text-center text-xs text-muted-foreground mt-6">
          Passwords are generated locally and never stored or transmitted
        </p>
      </div>
      <Toaster 
        position="bottom-center" 
        theme="dark"
        toastOptions={{
          style: {
            background: 'oklch(0.18 0.008 260)',
            border: '1px solid oklch(0.28 0.01 260)',
            color: 'oklch(0.98 0 0)',
          },
        }}
      />
    </main>
  )
}
