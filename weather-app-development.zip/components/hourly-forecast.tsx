interface HourlyData {
  time: string
  temperature: number
  condition: string
  icon: string
  windSpeed: number
  precipitation: number
}

interface Props {
  data: HourlyData[]
}

export default function HourlyForecast({ data }: Props) {
  return (
    <div className="mb-8">
      <h3 className="mb-4 text-xl font-bold text-foreground">
        Hourly Forecast
      </h3>
      <div className="overflow-x-auto rounded-2xl bg-card">
        <div className="flex gap-4 p-4">
          {data.map((hour, index) => (
            <div
              key={index}
              className="flex min-w-[120px] flex-col items-center rounded-lg bg-gradient-to-b from-secondary/10 to-secondary/5 px-4 py-4 transition hover:bg-secondary/20"
            >
              <p className="text-sm font-medium text-foreground">
                {hour.time}
              </p>
              <p className="my-2 text-3xl">{hour.icon}</p>
              <p className="text-lg font-bold text-primary">
                {hour.temperature}°
              </p>
              <p className="text-xs text-muted-foreground">
                {hour.condition}
              </p>
              <p className="mt-2 text-xs text-muted-foreground">
                💨 {hour.windSpeed} km/h
              </p>
              {hour.precipitation > 0 && (
                <p className="text-xs text-blue-500">
                  🌧️ {hour.precipitation.toFixed(1)}mm
                </p>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
