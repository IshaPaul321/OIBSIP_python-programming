export default function LoadingSpinner() {
  return (
    <div className="flex min-h-[400px] items-center justify-center">
      <div className="text-center">
        <div className="mb-4 inline-flex items-center justify-center">
          <div className="h-12 w-12 animate-spin rounded-full border-4 border-muted border-t-primary" />
        </div>
        <p className="text-lg font-medium text-foreground">
          Loading weather data...
        </p>
        <p className="mt-2 text-sm text-muted-foreground">
          This may take a moment
        </p>
      </div>
    </div>
  )
}
