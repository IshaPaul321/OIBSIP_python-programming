interface WeatherData {
  city: string
  country: string
  temperature: number
  feelsLike: number
  condition: string
  icon: string
  humidity: number
  windSpeed: number
  pressure: number
  uvIndex: number
  visibility: number
  sunrise: string
  sunset: string
}

interface Props {
  weather: WeatherData
}

export default function WeatherCard({ weather }: Props) {
  return (
    <div className="mb-8 overflow-hidden rounded-2xl bg-gradient-to-br from-primary to-primary/80 text-primary-foreground shadow-lg">
      <div className="p-8">
        <div className="mb-8 flex items-start justify-between">
          <div>
            <h2 className="text-5xl font-bold">
              {weather.temperature}°
            </h2>
            <p className="mt-2 text-lg opacity-90">{weather.condition}</p>
            <p className="mt-1 text-sm opacity-80">
              Feels like {weather.feelsLike}°
            </p>
          </div>
          <div className="text-8xl">{weather.icon}</div>
        </div>

        <div className="mb-6 text-sm opacity-80">
          <p className="font-medium">
            {weather.city}
            {weather.country ? `, ${weather.country}` : ''}
          </p>
        </div>

        {/* Weather Details Grid */}
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
          <div className="rounded-lg bg-white/10 p-4 backdrop-blur-sm">
            <p className="text-xs font-medium opacity-70">Humidity</p>
            <p className="mt-1 text-xl font-semibold">{weather.humidity}%</p>
          </div>
          <div className="rounded-lg bg-white/10 p-4 backdrop-blur-sm">
            <p className="text-xs font-medium opacity-70">Wind Speed</p>
            <p className="mt-1 text-xl font-semibold">{weather.windSpeed} km/h</p>
          </div>
          <div className="rounded-lg bg-white/10 p-4 backdrop-blur-sm">
            <p className="text-xs font-medium opacity-70">Pressure</p>
            <p className="mt-1 text-xl font-semibold">{weather.pressure} mb</p>
          </div>
          <div className="rounded-lg bg-white/10 p-4 backdrop-blur-sm">
            <p className="text-xs font-medium opacity-70">UV Index</p>
            <p className="mt-1 text-xl font-semibold">{weather.uvIndex}</p>
          </div>
          <div className="rounded-lg bg-white/10 p-4 backdrop-blur-sm">
            <p className="text-xs font-medium opacity-70">Visibility</p>
            <p className="mt-1 text-xl font-semibold">{weather.visibility} km</p>
          </div>
          <div className="rounded-lg bg-white/10 p-4 backdrop-blur-sm">
            <p className="text-xs font-medium opacity-70">Sunrise</p>
            <p className="mt-1 text-xl font-semibold">{weather.sunrise}</p>
          </div>
          <div className="rounded-lg bg-white/10 p-4 backdrop-blur-sm">
            <p className="text-xs font-medium opacity-70">Sunset</p>
            <p className="mt-1 text-xl font-semibold">{weather.sunset}</p>
          </div>
        </div>
      </div>
    </div>
  )
}
