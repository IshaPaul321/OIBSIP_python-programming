'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'

interface Props {
  onSearch: (city: string) => void
}

export default function SearchBar({ onSearch }: Props) {
  const [input, setInput] = useState('')

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (input.trim()) {
      onSearch(input)
      setInput('')
    }
  }

  return (
    <form onSubmit={handleSubmit} className="flex gap-2">
      <input
        type="text"
        placeholder="Search for a city..."
        value={input}
        onChange={(e) => setInput(e.target.value)}
        className="flex-1 rounded-lg border border-border bg-card px-4 py-3 text-foreground placeholder-muted-foreground transition focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20"
      />
      <Button
        type="submit"
        className="bg-primary text-primary-foreground hover:bg-primary/90"
      >
        Search
      </Button>
    </form>
  )
}
