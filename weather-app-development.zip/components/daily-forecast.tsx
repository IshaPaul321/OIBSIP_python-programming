interface DailyData {
  date: string
  high: number
  low: number
  condition: string
  icon: string
  precipitation: number
  windSpeed: number
}

interface Props {
  data: DailyData[]
}

export default function DailyForecast({ data }: Props) {
  return (
    <div className="mb-8">
      <h3 className="mb-4 text-xl font-bold text-foreground">
        7-Day Forecast
      </h3>
      <div className="space-y-2 rounded-2xl bg-card p-4">
        {data.map((day, index) => (
          <div
            key={index}
            className="flex items-center justify-between rounded-lg border border-border bg-gradient-to-r from-card to-card/50 px-4 py-4 transition hover:bg-muted/10"
          >
            <div className="flex items-center gap-4">
              <div className="w-20">
                <p className="font-medium text-foreground">{day.date}</p>
              </div>
              <p className="text-3xl">{day.icon}</p>
              <div>
                <p className="text-sm font-medium text-foreground">
                  {day.condition}
                </p>
                <div className="mt-1 flex gap-3 text-xs text-muted-foreground">
                  {day.precipitation > 0 && (
                    <span>🌧️ {day.precipitation.toFixed(1)}mm</span>
                  )}
                  <span>💨 {day.windSpeed} km/h</span>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-6">
              <div className="text-right">
                <p className="text-sm text-muted-foreground">High</p>
                <p className="text-xl font-bold text-primary">{day.high}°</p>
              </div>
              <div className="text-right">
                <p className="text-sm text-muted-foreground">Low</p>
                <p className="text-xl font-bold text-secondary">{day.low}°</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
