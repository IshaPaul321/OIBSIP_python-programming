'use client'

import { useState, useEffect } from 'react'
import WeatherCard from '@/components/weather-card'
import SearchBar from '@/components/search-bar'
import HourlyForecast from '@/components/hourly-forecast'
import DailyForecast from '@/components/daily-forecast'
import LoadingSpinner from '@/components/loading-spinner'

interface WeatherData {
  city: string
  country: string
  temperature: number
  feelsLike: number
  condition: string
  icon: string
  humidity: number
  windSpeed: number
  pressure: number
  uvIndex: number
  visibility: number
  sunrise: string
  sunset: string
}

interface HourlyData {
  time: string
  temperature: number
  condition: string
  icon: string
  windSpeed: number
  precipitation: number
}

interface DailyData {
  date: string
  high: number
  low: number
  condition: string
  icon: string
  precipitation: number
  windSpeed: number
}

export default function Page() {
  const [weather, setWeather] = useState<WeatherData | null>(null)
  const [hourly, setHourly] = useState<HourlyData[]>([])
  const [daily, setDaily] = useState<DailyData[]>([])
  const [loading, setLoading] = useState(true)
  const [city, setCity] = useState('San Francisco')
  const [error, setError] = useState('')

  const fetchWeather = async (cityName: string) => {
    try {
      setLoading(true)
      setError('')

      // Using Open-Meteo free API (no key required)
      const geocodingRes = await fetch(
        `https://geocoding-api.open-meteo.com/v1/search?name=${cityName}&count=1&language=en&format=json`
      )
      const geoData = await geocodingRes.json()

      if (!geoData.results || geoData.results.length === 0) {
        setError('City not found')
        setLoading(false)
        return
      }

      const { latitude, longitude, name, country } = geoData.results[0]

      const weatherRes = await fetch(
        `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m,pressure_msl,uv_index,visibility&hourly=temperature_2m,weather_code,wind_speed_10m,precipitation&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum,wind_speed_10m_max,sunrise,sunset&timezone=auto`
      )
      const weatherData = await weatherRes.json()

      const current = weatherData.current
      const getWeatherDesc = (code: number) => {
        const codes: { [key: number]: string } = {
          0: 'Clear',
          1: 'Mostly Clear',
          2: 'Partly Cloudy',
          3: 'Overcast',
          45: 'Foggy',
          48: 'Foggy',
          51: 'Light Drizzle',
          53: 'Drizzle',
          55: 'Heavy Drizzle',
          61: 'Light Rain',
          63: 'Rain',
          65: 'Heavy Rain',
          71: 'Light Snow',
          73: 'Snow',
          75: 'Heavy Snow',
          77: 'Snow Grains',
          80: 'Light Showers',
          81: 'Showers',
          82: 'Heavy Showers',
          85: 'Light Snow Showers',
          86: 'Snow Showers',
          95: 'Thunderstorm',
          96: 'Thunderstorm with Hail',
          99: 'Thunderstorm with Hail',
        }
        return codes[code] || 'Unknown'
      }

      const getWeatherIcon = (code: number) => {
        if (code === 0) return '☀️'
        if (code === 1 || code === 2) return '⛅'
        if (code === 3) return '☁️'
        if (code === 45 || code === 48) return '🌫️'
        if (code >= 51 && code <= 67) return '🌧️'
        if (code >= 71 && code <= 86) return '🌨️'
        if (code >= 80 && code <= 82) return '⛈️'
        if (code >= 95 && code <= 99) return '⛈️'
        return '🌤️'
      }

      setWeather({
        city: name,
        country: country || '',
        temperature: Math.round(current.temperature_2m),
        feelsLike: Math.round(current.apparent_temperature),
        condition: getWeatherDesc(current.weather_code),
        icon: getWeatherIcon(current.weather_code),
        humidity: current.relative_humidity_2m,
        windSpeed: Math.round(current.wind_speed_10m),
        pressure: Math.round(current.pressure_msl),
        uvIndex: Math.round(current.uv_index * 10) / 10,
        visibility: Math.round(current.visibility / 1000),
        sunrise: new Date(weatherData.daily.sunrise[0]).toLocaleTimeString('en-US', {
          hour: '2-digit',
          minute: '2-digit',
        }),
        sunset: new Date(weatherData.daily.sunset[0]).toLocaleTimeString('en-US', {
          hour: '2-digit',
          minute: '2-digit',
        }),
      })

      // Hourly forecast (next 24 hours)
      const hourlyData = []
      for (let i = 0; i < 24; i++) {
        hourlyData.push({
          time: new Date(weatherData.hourly.time[i]).toLocaleTimeString('en-US', {
            hour: '2-digit',
            minute: '2-digit',
          }),
          temperature: Math.round(weatherData.hourly.temperature_2m[i]),
          condition: getWeatherDesc(weatherData.hourly.weather_code[i]),
          icon: getWeatherIcon(weatherData.hourly.weather_code[i]),
          windSpeed: Math.round(weatherData.hourly.wind_speed_10m[i]),
          precipitation: weatherData.hourly.precipitation[i],
        })
      }
      setHourly(hourlyData)

      // Daily forecast (7 days)
      const dailyData = []
      for (let i = 0; i < 7; i++) {
        dailyData.push({
          date: new Date(weatherData.daily.time[i]).toLocaleDateString('en-US', {
            weekday: 'short',
            month: 'short',
            day: 'numeric',
          }),
          high: Math.round(weatherData.daily.temperature_2m_max[i]),
          low: Math.round(weatherData.daily.temperature_2m_min[i]),
          condition: getWeatherDesc(weatherData.daily.weather_code[i]),
          icon: getWeatherIcon(weatherData.daily.weather_code[i]),
          precipitation: weatherData.daily.precipitation_sum[i],
          windSpeed: Math.round(weatherData.daily.wind_speed_10m_max[i]),
        })
      }
      setDaily(dailyData)

      setLoading(false)
    } catch (err) {
      console.error('Error fetching weather:', err)
      setError('Failed to fetch weather data')
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchWeather(city)
  }, [])

  const handleSearch = (searchCity: string) => {
    setCity(searchCity)
    fetchWeather(searchCity)
  }

  return (
    <main className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <div className="border-b border-border bg-card">
        <div className="mx-auto max-w-6xl px-4 py-6 sm:px-6 lg:px-8">
          <div className="mb-6 flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold">Weather</h1>
              <p className="text-muted-foreground">Check the weather anywhere</p>
            </div>
          </div>
          <SearchBar onSearch={handleSearch} />
        </div>
      </div>

      {/* Main Content */}
      <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6 lg:px-8">
        {loading && <LoadingSpinner />}

        {error && (
          <div className="rounded-lg bg-destructive/10 p-4 text-destructive">
            <p className="font-medium">{error}</p>
          </div>
        )}

        {!loading && !error && weather && (
          <>
            {/* Current Weather */}
            <WeatherCard weather={weather} />

            {/* Hourly Forecast */}
            {hourly.length > 0 && <HourlyForecast data={hourly} />}

            {/* Daily Forecast */}
            {daily.length > 0 && <DailyForecast data={daily} />}
          </>
        )}
      </div>
    </main>
  )
}
