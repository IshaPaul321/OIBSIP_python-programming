'use client'

import { useState, useEffect, useCallback } from 'react'
import { BMICalculator } from '@/components/bmi-calculator'
import { BMIHistory } from '@/components/bmi-history'
import { BMIChart } from '@/components/bmi-chart'
import { getBMIHistory, type BMIRecord } from '@/lib/bmi-utils'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Activity, History, BarChart3 } from 'lucide-react'

export default function Home() {
  const [records, setRecords] = useState<BMIRecord[]>([])
  const [mounted, setMounted] = useState(false)

  const loadRecords = useCallback(() => {
    setRecords(getBMIHistory())
  }, [])

  useEffect(() => {
    setMounted(true)
    loadRecords()
  }, [loadRecords])

  if (!mounted) {
    return (
      <main className="min-h-screen bg-background">
        <div className="container mx-auto max-w-4xl px-4 py-8">
          <div className="flex flex-col items-center justify-center min-h-[50vh]">
            <div className="animate-pulse space-y-4 w-full max-w-md">
              <div className="h-8 bg-muted rounded w-3/4 mx-auto" />
              <div className="h-4 bg-muted rounded w-1/2 mx-auto" />
              <div className="h-64 bg-muted rounded" />
            </div>
          </div>
        </div>
      </main>
    )
  }

  return (
    <main className="min-h-screen bg-background">
      <div className="container mx-auto max-w-4xl px-4 py-8">
        <header className="mb-8 text-center">
          <div className="inline-flex items-center justify-center gap-3 mb-4">
            <div className="p-3 rounded-xl bg-primary/10">
              <Activity className="h-8 w-8 text-primary" />
            </div>
          </div>
          <h1 className="text-3xl font-bold tracking-tight text-balance sm:text-4xl">
            BMI Calculator
          </h1>
          <p className="mt-2 text-muted-foreground text-pretty max-w-md mx-auto">
            Calculate your Body Mass Index and track your health journey over time
          </p>
        </header>

        <Tabs defaultValue="calculator" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="calculator" className="flex items-center gap-2">
              <Activity className="h-4 w-4" />
              <span className="hidden sm:inline">Calculator</span>
            </TabsTrigger>
            <TabsTrigger value="history" className="flex items-center gap-2">
              <History className="h-4 w-4" />
              <span className="hidden sm:inline">History</span>
              {records.length > 0 && (
                <span className="ml-1 rounded-full bg-primary/10 px-2 py-0.5 text-xs font-medium text-primary">
                  {records.length}
                </span>
              )}
            </TabsTrigger>
            <TabsTrigger value="trends" className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              <span className="hidden sm:inline">Trends</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="calculator" className="space-y-6">
            <BMICalculator onRecordAdded={loadRecords} />
          </TabsContent>

          <TabsContent value="history" className="space-y-6">
            <BMIHistory records={records} onRecordsChange={loadRecords} />
          </TabsContent>

          <TabsContent value="trends" className="space-y-6">
            <BMIChart records={records} />
          </TabsContent>
        </Tabs>

        <footer className="mt-12 text-center text-sm text-muted-foreground">
          <p>
            BMI is a screening tool and may not be accurate for athletes, elderly,
            or pregnant individuals.
          </p>
          <p className="mt-1">Always consult a healthcare provider for medical advice.</p>
        </footer>
      </div>
    </main>
  )
}
