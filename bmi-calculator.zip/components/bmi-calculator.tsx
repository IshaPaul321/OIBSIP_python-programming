'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import {
  calculateBMI,
  getBMICategory,
  getCategoryLabel,
  getCategoryDescription,
  getCategoryColor,
  getCategoryBgColor,
  saveBMIRecord,
  generateId,
  type BMICategory,
} from '@/lib/bmi-utils'
import { Activity, Scale, Ruler } from 'lucide-react'

interface BMICalculatorProps {
  onRecordAdded: () => void
}

export function BMICalculator({ onRecordAdded }: BMICalculatorProps) {
  const [weight, setWeight] = useState('')
  const [height, setHeight] = useState('')
  const [name, setName] = useState('')
  const [result, setResult] = useState<{
    bmi: number
    category: BMICategory
  } | null>(null)
  const [errors, setErrors] = useState<{ weight?: string; height?: string }>({})

  const validateInputs = (): boolean => {
    const newErrors: { weight?: string; height?: string } = {}

    const weightNum = parseFloat(weight)
    const heightNum = parseFloat(height)

    if (!weight || isNaN(weightNum)) {
      newErrors.weight = 'Please enter a valid weight'
    } else if (weightNum < 20 || weightNum > 500) {
      newErrors.weight = 'Weight must be between 20-500 kg'
    }

    if (!height || isNaN(heightNum)) {
      newErrors.height = 'Please enter a valid height'
    } else if (heightNum < 0.5 || heightNum > 2.5) {
      newErrors.height = 'Height must be between 0.5-2.5 m'
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleCalculate = () => {
    if (!validateInputs()) return

    const weightNum = parseFloat(weight)
    const heightNum = parseFloat(height)
    const bmi = calculateBMI(weightNum, heightNum)
    const category = getBMICategory(bmi)

    setResult({ bmi, category })

    const record = {
      id: generateId(),
      weight: weightNum,
      height: heightNum,
      bmi,
      category,
      date: new Date().toISOString(),
      name: name.trim() || undefined,
    }

    saveBMIRecord(record)
    onRecordAdded()
  }

  const handleReset = () => {
    setWeight('')
    setHeight('')
    setName('')
    setResult(null)
    setErrors({})
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5 text-primary" />
            Calculate Your BMI
          </CardTitle>
          <CardDescription>
            Enter your weight and height to calculate your Body Mass Index
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Name (Optional)</Label>
            <Input
              id="name"
              type="text"
              placeholder="Enter your name"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="weight" className="flex items-center gap-2">
                <Scale className="h-4 w-4 text-muted-foreground" />
                Weight (kg)
              </Label>
              <Input
                id="weight"
                type="number"
                placeholder="e.g., 70"
                value={weight}
                onChange={(e) => {
                  setWeight(e.target.value)
                  if (errors.weight) setErrors((prev) => ({ ...prev, weight: undefined }))
                }}
                min="20"
                max="500"
                step="0.1"
                aria-invalid={!!errors.weight}
              />
              {errors.weight && (
                <p className="text-sm text-destructive">{errors.weight}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="height" className="flex items-center gap-2">
                <Ruler className="h-4 w-4 text-muted-foreground" />
                Height (m)
              </Label>
              <Input
                id="height"
                type="number"
                placeholder="e.g., 1.75"
                value={height}
                onChange={(e) => {
                  setHeight(e.target.value)
                  if (errors.height) setErrors((prev) => ({ ...prev, height: undefined }))
                }}
                min="0.5"
                max="2.5"
                step="0.01"
                aria-invalid={!!errors.height}
              />
              {errors.height && (
                <p className="text-sm text-destructive">{errors.height}</p>
              )}
            </div>
          </div>

          <div className="flex gap-3 pt-2">
            <Button onClick={handleCalculate} className="flex-1">
              Calculate BMI
            </Button>
            <Button variant="outline" onClick={handleReset}>
              Reset
            </Button>
          </div>
        </CardContent>
      </Card>

      {result && (
        <Card className="overflow-hidden">
          <div className={`h-2 ${getCategoryBgColor(result.category)}`} />
          <CardHeader>
            <CardTitle>Your Result</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">BMI Value</p>
                <p className={`text-4xl font-bold ${getCategoryColor(result.category)}`}>
                  {result.bmi.toFixed(1)}
                </p>
              </div>
              <div className="text-right">
                <p className="text-sm text-muted-foreground">Category</p>
                <p className={`text-xl font-semibold ${getCategoryColor(result.category)}`}>
                  {getCategoryLabel(result.category)}
                </p>
              </div>
            </div>
            <p className="text-muted-foreground">
              {getCategoryDescription(result.category)}
            </p>

            <div className="space-y-2">
              <p className="text-sm font-medium">BMI Categories</p>
              <div className="grid grid-cols-4 gap-1 rounded-lg overflow-hidden">
                <div className="bg-underweight p-2 text-center">
                  <p className="text-xs text-primary-foreground font-medium">{'<'}18.5</p>
                </div>
                <div className="bg-normal p-2 text-center">
                  <p className="text-xs text-primary-foreground font-medium">18.5-24.9</p>
                </div>
                <div className="bg-overweight p-2 text-center">
                  <p className="text-xs text-primary-foreground font-medium">25-29.9</p>
                </div>
                <div className="bg-obese p-2 text-center">
                  <p className="text-xs text-primary-foreground font-medium">30+</p>
                </div>
              </div>
              <div className="grid grid-cols-4 gap-1 text-center text-xs text-muted-foreground">
                <span>Underweight</span>
                <span>Normal</span>
                <span>Overweight</span>
                <span>Obese</span>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
