'use client'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { type BMIRecord } from '@/lib/bmi-utils'
import { TrendingUp, TrendingDown, Minus, BarChart3 } from 'lucide-react'
import { format } from 'date-fns'
import {
  Area,
  AreaChart,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine,
} from 'recharts'

interface BMIChartProps {
  records: BMIRecord[]
}

export function BMIChart({ records }: BMIChartProps) {
  if (records.length < 2) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5 text-primary" />
            BMI Trend
          </CardTitle>
          <CardDescription>Track your BMI changes over time</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center py-8 text-center">
            <BarChart3 className="h-12 w-12 text-muted-foreground/50 mb-4" />
            <p className="text-muted-foreground">Not enough data</p>
            <p className="text-sm text-muted-foreground">
              Add at least 2 records to see the trend
            </p>
          </div>
        </CardContent>
      </Card>
    )
  }

  const chartData = [...records]
    .reverse()
    .slice(-20)
    .map((record) => ({
      date: format(new Date(record.date), 'MMM d'),
      bmi: parseFloat(record.bmi.toFixed(1)),
      fullDate: format(new Date(record.date), 'MMM d, yyyy'),
    }))

  const latestBMI = records[0]?.bmi || 0
  const previousBMI = records[1]?.bmi || latestBMI
  const change = latestBMI - previousBMI
  const percentChange = previousBMI > 0 ? ((change / previousBMI) * 100).toFixed(1) : '0'

  const avgBMI = records.reduce((sum, r) => sum + r.bmi, 0) / records.length
  const minBMI = Math.min(...records.map((r) => r.bmi))
  const maxBMI = Math.max(...records.map((r) => r.bmi))

  const getTrendIcon = () => {
    if (change > 0.1) return <TrendingUp className="h-4 w-4 text-accent" />
    if (change < -0.1) return <TrendingDown className="h-4 w-4 text-primary" />
    return <Minus className="h-4 w-4 text-muted-foreground" />
  }

  const getTrendText = () => {
    if (change > 0.1) return 'text-accent'
    if (change < -0.1) return 'text-primary'
    return 'text-muted-foreground'
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <BarChart3 className="h-5 w-5 text-primary" />
          BMI Trend
        </CardTitle>
        <CardDescription>
          Showing your last {chartData.length} records
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground">Latest BMI</p>
            <p className="text-2xl font-bold">{latestBMI.toFixed(1)}</p>
          </div>
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground">Change</p>
            <div className="flex items-center gap-1">
              {getTrendIcon()}
              <span className={`text-2xl font-bold ${getTrendText()}`}>
                {change > 0 ? '+' : ''}
                {change.toFixed(1)}
              </span>
            </div>
            <p className={`text-xs ${getTrendText()}`}>
              {change > 0 ? '+' : ''}
              {percentChange}%
            </p>
          </div>
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground">Average</p>
            <p className="text-2xl font-bold">{avgBMI.toFixed(1)}</p>
          </div>
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground">Range</p>
            <p className="text-2xl font-bold">
              {minBMI.toFixed(1)}-{maxBMI.toFixed(1)}
            </p>
          </div>
        </div>

        <div className="h-[300px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart
              data={chartData}
              margin={{ top: 10, right: 10, left: 0, bottom: 0 }}
            >
              <defs>
                <linearGradient id="bmiGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="oklch(0.55 0.15 160)" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="oklch(0.55 0.15 160)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
              <XAxis
                dataKey="date"
                tick={{ fontSize: 12 }}
                tickLine={false}
                axisLine={false}
                className="fill-muted-foreground"
              />
              <YAxis
                domain={['dataMin - 2', 'dataMax + 2']}
                tick={{ fontSize: 12 }}
                tickLine={false}
                axisLine={false}
                className="fill-muted-foreground"
              />
              <Tooltip
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    return (
                      <div className="rounded-lg border bg-card p-3 shadow-lg">
                        <p className="text-sm font-medium">{payload[0].payload.fullDate}</p>
                        <p className="text-lg font-bold text-primary">
                          BMI: {payload[0].value}
                        </p>
                      </div>
                    )
                  }
                  return null
                }}
              />
              <ReferenceLine
                y={18.5}
                stroke="oklch(0.6 0.15 200)"
                strokeDasharray="3 3"
                strokeOpacity={0.5}
              />
              <ReferenceLine
                y={25}
                stroke="oklch(0.65 0.18 85)"
                strokeDasharray="3 3"
                strokeOpacity={0.5}
              />
              <ReferenceLine
                y={30}
                stroke="oklch(0.55 0.2 25)"
                strokeDasharray="3 3"
                strokeOpacity={0.5}
              />
              <Area
                type="monotone"
                dataKey="bmi"
                stroke="oklch(0.55 0.15 160)"
                strokeWidth={2}
                fill="url(#bmiGradient)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div className="flex flex-wrap justify-center gap-4 text-xs text-muted-foreground">
          <div className="flex items-center gap-2">
            <div className="h-0.5 w-4 bg-underweight" style={{ opacity: 0.5 }} />
            <span>Underweight ({'<'}18.5)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="h-0.5 w-4 bg-overweight" style={{ opacity: 0.5 }} />
            <span>Overweight (25)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="h-0.5 w-4 bg-obese" style={{ opacity: 0.5 }} />
            <span>Obese (30)</span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
