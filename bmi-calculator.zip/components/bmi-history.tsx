'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import {
  type BMIRecord,
  getCategoryLabel,
  getCategoryColor,
  deleteBMIRecord,
  clearBMIHistory,
} from '@/lib/bmi-utils'
import { History, Trash2, AlertTriangle } from 'lucide-react'
import { format } from 'date-fns'

interface BMIHistoryProps {
  records: BMIRecord[]
  onRecordsChange: () => void
}

export function BMIHistory({ records, onRecordsChange }: BMIHistoryProps) {
  const [deleteId, setDeleteId] = useState<string | null>(null)

  const handleDelete = (id: string) => {
    deleteBMIRecord(id)
    setDeleteId(null)
    onRecordsChange()
  }

  const handleClearAll = () => {
    clearBMIHistory()
    onRecordsChange()
  }

  if (records.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <History className="h-5 w-5 text-primary" />
            History
          </CardTitle>
          <CardDescription>Your BMI calculation history will appear here</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center py-8 text-center">
            <History className="h-12 w-12 text-muted-foreground/50 mb-4" />
            <p className="text-muted-foreground">No records yet</p>
            <p className="text-sm text-muted-foreground">
              Calculate your BMI to start tracking
            </p>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
        <div>
          <CardTitle className="flex items-center gap-2">
            <History className="h-5 w-5 text-primary" />
            History
          </CardTitle>
          <CardDescription>{records.length} record(s) saved</CardDescription>
        </div>
        <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button variant="outline" size="sm" className="text-destructive">
              <Trash2 className="h-4 w-4 mr-1" />
              Clear All
            </Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-destructive" />
                Clear All History
              </AlertDialogTitle>
              <AlertDialogDescription>
                This will permanently delete all {records.length} BMI records. This action cannot
                be undone.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction
                onClick={handleClearAll}
                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              >
                Clear All
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </CardHeader>
      <CardContent>
        <div className="rounded-lg border overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date</TableHead>
                <TableHead>Name</TableHead>
                <TableHead className="text-right">Weight</TableHead>
                <TableHead className="text-right">Height</TableHead>
                <TableHead className="text-right">BMI</TableHead>
                <TableHead>Category</TableHead>
                <TableHead className="w-[50px]"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {records.map((record) => (
                <TableRow key={record.id}>
                  <TableCell className="font-medium">
                    {format(new Date(record.date), 'MMM d, yyyy')}
                  </TableCell>
                  <TableCell>{record.name || '-'}</TableCell>
                  <TableCell className="text-right">{record.weight} kg</TableCell>
                  <TableCell className="text-right">{record.height} m</TableCell>
                  <TableCell className="text-right font-semibold">
                    {record.bmi.toFixed(1)}
                  </TableCell>
                  <TableCell>
                    <span className={`font-medium ${getCategoryColor(record.category)}`}>
                      {getCategoryLabel(record.category)}
                    </span>
                  </TableCell>
                  <TableCell>
                    <AlertDialog
                      open={deleteId === record.id}
                      onOpenChange={(open) => !open && setDeleteId(null)}
                    >
                      <AlertDialogTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-muted-foreground hover:text-destructive"
                          onClick={() => setDeleteId(record.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                          <span className="sr-only">Delete record</span>
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Delete Record</AlertDialogTitle>
                          <AlertDialogDescription>
                            Are you sure you want to delete this BMI record from{' '}
                            {format(new Date(record.date), 'MMMM d, yyyy')}?
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancel</AlertDialogCancel>
                          <AlertDialogAction
                            onClick={() => handleDelete(record.id)}
                            className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                          >
                            Delete
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  )
}
