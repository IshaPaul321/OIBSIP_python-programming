export interface BMIRecord {
  id: string
  weight: number
  height: number
  bmi: number
  category: BMICategory
  date: string
  name?: string
}

export type BMICategory = 'underweight' | 'normal' | 'overweight' | 'obese'

export function calculateBMI(weight: number, height: number): number {
  if (weight <= 0 || height <= 0) return 0
  return weight / (height * height)
}

export function getBMICategory(bmi: number): BMICategory {
  if (bmi < 18.5) return 'underweight'
  if (bmi < 25) return 'normal'
  if (bmi < 30) return 'overweight'
  return 'obese'
}

export function getCategoryLabel(category: BMICategory): string {
  const labels: Record<BMICategory, string> = {
    underweight: 'Underweight',
    normal: 'Normal',
    overweight: 'Overweight',
    obese: 'Obese',
  }
  return labels[category]
}

export function getCategoryDescription(category: BMICategory): string {
  const descriptions: Record<BMICategory, string> = {
    underweight: 'Your BMI is below 18.5. Consider consulting a healthcare provider.',
    normal: 'Your BMI is in the healthy range. Keep up the good work!',
    overweight: 'Your BMI is between 25 and 30. Consider lifestyle changes.',
    obese: 'Your BMI is 30 or above. Please consult a healthcare provider.',
  }
  return descriptions[category]
}

export function getCategoryColor(category: BMICategory): string {
  const colors: Record<BMICategory, string> = {
    underweight: 'text-underweight',
    normal: 'text-normal',
    overweight: 'text-overweight',
    obese: 'text-obese',
  }
  return colors[category]
}

export function getCategoryBgColor(category: BMICategory): string {
  const colors: Record<BMICategory, string> = {
    underweight: 'bg-underweight',
    normal: 'bg-normal',
    overweight: 'bg-overweight',
    obese: 'bg-obese',
  }
  return colors[category]
}

const STORAGE_KEY = 'bmi-history'

export function saveBMIRecord(record: BMIRecord): void {
  const history = getBMIHistory()
  history.unshift(record)
  if (typeof window !== 'undefined') {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(history))
  }
}

export function getBMIHistory(): BMIRecord[] {
  if (typeof window === 'undefined') return []
  const data = localStorage.getItem(STORAGE_KEY)
  return data ? JSON.parse(data) : []
}

export function deleteBMIRecord(id: string): void {
  const history = getBMIHistory()
  const filtered = history.filter((record) => record.id !== id)
  if (typeof window !== 'undefined') {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(filtered))
  }
}

export function clearBMIHistory(): void {
  if (typeof window !== 'undefined') {
    localStorage.removeItem(STORAGE_KEY)
  }
}

export function generateId(): string {
  return Date.now().toString(36) + Math.random().toString(36).substr(2)
}
